define({ "api": [
  {
    "type": "POST",
    "url": "/address/add",
    "title": "AddAddress",
    "version": "1.0.0",
    "name": "AddAddress",
    "group": "AddressMgmt",
    "examples": [
      {
        "title": "Request-Example:",
        "content": "http://localhost/api/v1.0/address/add",
        "type": "Text"
      }
    ],
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "Content-Type",
            "description": "<p>The accept data type, it must be 'application/json'</p>"
          }
        ]
      }
    },
    "parameter": {
      "examples": [
        {
          "title": "Request-Body Example:",
          "content": "{\n   \"memberId\":\"1\",\n   \"name\":\"小李\",\n   \"mobile\":\"17782476837\",\n   \"province\":\"陕西\",\n   \"city\":\"西安\"，\n   \"region\":\"长安区\"，\n   \"addr\":\"西安电子科技大学南校区\"\n}",
          "type": "json"
        }
      ],
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "memberId",
            "description": "<p>the id of user.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>the name of consignee.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "mobile",
            "description": "<p>the phone number of consignee.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "province",
            "description": "<p>the province of consignee.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "city",
            "description": "<p>the city of consignee.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "region",
            "description": "<p>the region of consignee.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "addr",
            "description": "<p>the detailed street of consignee.</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "  HTTP/1.1 200 OK\n{\n    \"result\":\"success\",\n    \"addressId\":\"1\"\n}",
          "type": "json"
        }
      ]
    },
    "filename": "src/main/java/com/xidian/bookstore/apidoc/AddressApiDoc.java",
    "groupTitle": "AddressMgmt"
  },
  {
    "type": "POST",
    "url": "/address/delete",
    "title": "DeleteAddress",
    "version": "1.0.0",
    "name": "DeleteAddress",
    "group": "AddressMgmt",
    "examples": [
      {
        "title": "Request-Example:",
        "content": "http://localhost/api/v1.0/address/delete?addressId=1",
        "type": "Text"
      }
    ],
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "Content-Type",
            "description": "<p>The accept data type, it must be 'application/json'.</p>"
          }
        ]
      }
    },
    "parameter": {
      "examples": [
        {
          "title": "Request-Body Example:",
          "content": "{\n   \"addressId\":[\"1\",\"2\"],\n}",
          "type": "json"
        }
      ],
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Array",
            "optional": false,
            "field": "addressId",
            "description": "<p>the id of address.</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "  HTTP/1.1 200 OK\n{\n    \"result\":\"success\"\n}",
          "type": "json"
        }
      ]
    },
    "filename": "src/main/java/com/xidian/bookstore/apidoc/AddressApiDoc.java",
    "groupTitle": "AddressMgmt"
  },
  {
    "type": "GET",
    "url": "/address/list",
    "title": "GetAddress",
    "version": "1.0.0",
    "name": "GetAddress",
    "group": "AddressMgmt",
    "examples": [
      {
        "title": "Request-Example:",
        "content": "http://localhost/api/v1.0/address/list?memberId=1",
        "type": "Text"
      }
    ],
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "Content-Type",
            "description": "<p>The accept data type, it must be 'application/json'.</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "  HTTP/1.1 200 OK\n{\n    \"addresses\":[\n     {\n         \"addressId\":\"1\",\n         \"name\":\"小李\",\n         \"mobile\":\"17782476837\",\n         \"province\":\"陕西\",\n         \"city\":\"西安\"，\n         \"region\":\"长安区\"，\n         \"addr\":\"西安电子科技大学南校区\"\n     },\n     {\n         \"addressId\":\"2\",\n         \"name\":\"小明\",\n         \"mobile\":\"17782476837\",\n         \"province\":\"陕西\",\n         \"city\":\"西安\"，\n         \"region\":\"雁塔区\"，\n         \"addr\":\"西安电子科技大学北校区\"\n     }\n    ]\n}",
          "type": "json"
        }
      ]
    },
    "filename": "src/main/java/com/xidian/bookstore/apidoc/AddressApiDoc.java",
    "groupTitle": "AddressMgmt"
  },
  {
    "type": "PUT",
    "url": "/address/update",
    "title": "UpdateAddress",
    "version": "1.0.0",
    "name": "UpdateAddress",
    "group": "AddressMgmt",
    "examples": [
      {
        "title": "Request-Example:",
        "content": "http://localhost/api/v1.0/address/update",
        "type": "Text"
      }
    ],
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "Content-Type",
            "description": "<p>The accept data type, it must be 'application/json'</p>"
          }
        ]
      }
    },
    "parameter": {
      "examples": [
        {
          "title": "Request-Body Example:",
          "content": "{\n   \"addressId\":\"1\",\n   \"name\":\"小李\",\n   \"mobile\":\"17782476837\",\n   \"province\":\"陕西\",\n   \"city\":\"西安\"，\n   \"region\":\"长安区\"，\n   \"addr\":\"西安电子科技大学南校区\"\n}",
          "type": "json"
        }
      ],
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "addressId",
            "description": "<p>the id of consignee.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": true,
            "field": "name",
            "description": "<p>the name of consignee.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": true,
            "field": "mobile",
            "description": "<p>the phone number of consignee.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": true,
            "field": "province",
            "description": "<p>the province of consignee.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": true,
            "field": "city",
            "description": "<p>the city of consignee.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": true,
            "field": "region",
            "description": "<p>the region of consignee.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": true,
            "field": "addr",
            "description": "<p>the detailed street of consignee.</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "  HTTP/1.1 200 OK\n{\n    \"result\":\"success\"\n}",
          "type": "json"
        }
      ]
    },
    "filename": "src/main/java/com/xidian/bookstore/apidoc/AddressApiDoc.java",
    "groupTitle": "AddressMgmt"
  },
  {
    "type": "POST",
    "url": "/book/collect",
    "title": "CollectBook",
    "version": "1.0.0",
    "name": "CollectBook",
    "group": "BookMgmt",
    "examples": [
      {
        "title": "Request-Example:",
        "content": "http://localhost/api/v1.0/book/collect",
        "type": "Text"
      }
    ],
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "Content-Type",
            "description": "<p>The accept data type, it must be 'application/json'</p>"
          }
        ]
      }
    },
    "parameter": {
      "examples": [
        {
          "title": "Request-Body Example:",
          "content": "{\n   \"userId\":\"1\",\n   \"bookId\": \"1\",\n   \"description\":\"收藏的描述\"\n}",
          "type": "json"
        }
      ],
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "userId",
            "description": "<p>the id of user.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "bookId",
            "description": "<p>the id of book.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "description",
            "description": "<p>the description of collection.</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "  HTTP/1.1 200 OK\n{\n    \"result\":\"success\"\n}",
          "type": "json"
        }
      ]
    },
    "filename": "src/main/java/com/xidian/bookstore/apidoc/BookApiDoc.java",
    "groupTitle": "BookMgmt"
  },
  {
    "type": "POST",
    "url": "/book/delete",
    "title": "DeleteBook",
    "version": "1.0.0",
    "name": "DeleteBook",
    "group": "BookMgmt",
    "examples": [
      {
        "title": "Request-Example:",
        "content": "http://localhost/api/v1.0/book/delete",
        "type": "Text"
      }
    ],
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "Content-Type",
            "description": "<p>The accept data type, it must be 'application/json'.</p>"
          }
        ]
      }
    },
    "parameter": {
      "examples": [
        {
          "title": "Request-Body Example:",
          "content": "{\n   \"bookId\":[\"1\",\"2\"],\n}",
          "type": "json"
        }
      ],
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Array",
            "optional": false,
            "field": "bookId",
            "description": "<p>the id of book.</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "  HTTP/1.1 200 OK\n{\n    \"result\":\"success\"\n}",
          "type": "json"
        }
      ]
    },
    "filename": "src/main/java/com/xidian/bookstore/apidoc/BookApiDoc.java",
    "groupTitle": "BookMgmt"
  },
  {
    "type": "post",
    "url": "/book/fuzzysearch",
    "title": "SearchBook",
    "version": "1.0.0",
    "name": "SearchBook",
    "group": "BookMgmt",
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "Accept",
            "description": "<p>The accept data type, must is 'application/json'</p>"
          }
        ]
      }
    },
    "parameter": {
      "examples": [
        {
          "title": "Request-Body Example:",
          "content": "{\n   \"clause\":{\n       \"key1\": \"value1\",\n       \"keyn\":\"valuen\"\n     },\n   \"like\":{\n       \"key1\": \"value1\",\n       \"keyn\": \"valuen\"\n     },\n   \"filter\":\n   {\n       \"page\": \"0\",\n       \"size\": \"3\"\n\n   },\n\n   \"orderBy\":\n   {\n       \"field\": \"price\",\n       \"order\": \"asc\"\n   }\n\n}",
          "type": "json"
        }
      ],
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Object",
            "optional": true,
            "field": "clause",
            "description": "<p>Each item is &quot;And&quot; operation().</p>"
          },
          {
            "group": "Parameter",
            "type": "Object",
            "optional": true,
            "field": "like",
            "description": "<p>Each item is &quot;OR&quot; fuzzy search operation().</p>"
          },
          {
            "group": "Parameter",
            "type": "Object",
            "optional": false,
            "field": "filter",
            "description": "<p>Filter search result,we must select filter by paging.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "filter.page",
            "description": "<p>Filter search result by current page.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "filter.size",
            "description": "<p>Filter search result by size of the current page.</p>"
          },
          {
            "group": "Parameter",
            "type": "Object",
            "optional": true,
            "field": "orderBy",
            "description": "<p>Sort search result.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": true,
            "field": "orderBy.order",
            "description": "<p>Sort search result by DESCending or ASCending(&quot;asc&quot; or &quot;desc&quot;) default by asc.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": true,
            "field": "orderBy.field",
            "description": "<p>Sort search result by field (it can be price ,purchaseNumber and browseNumber) default by purchaseNumber.</p>"
          }
        ]
      }
    },
    "examples": [
      {
        "title": "Request-Example:",
        "content": "http://localhost/api/v1.0/book/fuzzysearch",
        "type": "Text"
      }
    ],
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "    HTTP/1.1 200 OK\n{\n \"totalCount\": 22,\n \"totalPage\": 3,\n \"currentCount\": 2,\n \"currentPage\": 3,\n \"data\": [\n {\n  \"bookId\": \"1\",\n  \"bookName\": \"MySql必知必会\",\n  \"price\": \"30.00\",\n  \"publisherName\": \"人民邮电出版社\",\n  \"author\": \"Ben Forta\",\n  \"inventory\": \"50\"，\n  \"intro\": \"MySql数据库基础入门必备\"，\n  \"image\": \"\",\n  \"browseNumber\":\"100\",\n  \"purchaseNumber\":\"50\"，\n  \"creatime\":\"2019年4月12日\"\n },\n {\n  \"bookId\": \"2\",\n  \"bookName\": \"Java程序员面试笔试宝典\",\n  \"price\": \"48.80\",\n  \"publisherName\": \"机械工业出版社\",\n  \"author\": \"何昊 薛鹏 叶向阳\",\n  \"inventory\": \"50\"，\n  \"intro\": \"java面试必备\"，\n  \"image\": \"\",\n  \"browseNumber\":\"100\",\n  \"purchaseNumber\":\"50\"，\n  \"creatime\":\"2019年4月12日\"\n }\n]\n}",
          "type": "json"
        }
      ]
    },
    "filename": "src/main/java/com/xidian/bookstore/apidoc/BookApiDoc.java",
    "groupTitle": "BookMgmt"
  },
  {
    "type": "PUT",
    "url": "/book/update",
    "title": "UpdateBook",
    "version": "1.0.0",
    "name": "UpdateBook",
    "group": "BookMgmt",
    "examples": [
      {
        "title": "Request-Example:",
        "content": "http://localhost/api/v1.0/book/update",
        "type": "Text"
      }
    ],
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "Content-Type",
            "description": "<p>The accept data type, it must be 'application/json'</p>"
          }
        ]
      }
    },
    "parameter": {
      "examples": [
        {
          "title": "Request-Body Example:",
          "content": "{\n  \"bookName\": \"MySql必知必会\",\n  \"price\": \"30.00\",\n  \"publisherName\": \"人民邮电出版社\",\n  \"author\": \"Ben Forta\",\n  \"inventory\": \"50\"，\n  \"intro\": \"MySql数据库基础入门必备\"，\n  \"picture\": \"\",\n  \"categoryId\":\"00\",\n  \"tagId\":\"01\"\n}",
          "type": "json"
        }
      ],
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": true,
            "field": "bookName",
            "description": "<p>the name of book.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": true,
            "field": "price",
            "description": "<p>the price of book.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": true,
            "field": "publisherName",
            "description": "<p>the name of publisher.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": true,
            "field": "author",
            "description": "<p>the name of author.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": true,
            "field": "inventory",
            "description": "<p>the number of book.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": true,
            "field": "intro",
            "description": "<p>the description of book.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": true,
            "field": "picture",
            "description": "<p>the photo of book.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": true,
            "field": "categoryId",
            "description": "<p>the id of book's category.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": true,
            "field": "tagId",
            "description": "<p>the id of book's tag.</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "  HTTP/1.1 200 OK\n{\n    \"result\":\"success\"\n}",
          "type": "json"
        }
      ]
    },
    "filename": "src/main/java/com/xidian/bookstore/apidoc/BookApiDoc.java",
    "groupTitle": "BookMgmt"
  },
  {
    "type": "POST",
    "url": "/book/upload",
    "title": "UploadBook",
    "version": "1.0.0",
    "name": "UploadBook",
    "group": "BookMgmt",
    "examples": [
      {
        "title": "Request-Example:",
        "content": "http://localhost/api/v1.0/book/upload",
        "type": "Text"
      }
    ],
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "Content-Type",
            "description": "<p>The accept data type, it must be 'application/json'</p>"
          }
        ]
      }
    },
    "parameter": {
      "examples": [
        {
          "title": "Request-Body Example:",
          "content": "{\n  \"bookName\": \"MySql必知必会\",\n  \"price\": \"30.00\",\n  \"publisherName\": \"人民邮电出版社\",\n  \"author\": \"Ben Forta\",\n  \"inventory\": \"50\"，\n  \"intro\": \"MySql数据库基础入门必备\"，\n  \"picture\": \"\",\n  \"categoryId\":\"00\",\n  \"tagId\":\"01\"\n}",
          "type": "json"
        }
      ],
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "bookName",
            "description": "<p>the name of book.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "price",
            "description": "<p>the price of book.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "publisherName",
            "description": "<p>the name of publisher.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "author",
            "description": "<p>the name of author.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "inventory",
            "description": "<p>the number of book.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "intro",
            "description": "<p>the description of book.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "picture",
            "description": "<p>the photo of book.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "categoryId",
            "description": "<p>the id of book's category.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "tagId",
            "description": "<p>the id of book's tag.</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "  HTTP/1.1 200 OK\n{\n    \"result\":\"success\"\n}",
          "type": "json"
        }
      ]
    },
    "filename": "src/main/java/com/xidian/bookstore/apidoc/BookApiDoc.java",
    "groupTitle": "BookMgmt"
  },
  {
    "type": "POST",
    "url": "/cart/add",
    "title": "AddCart",
    "version": "1.0.0",
    "name": "AddCart",
    "group": "CartMgmt",
    "examples": [
      {
        "title": "Request-Example:",
        "content": "http://localhost/api/v1.0/cart/add",
        "type": "Text"
      }
    ],
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "Content-Type",
            "description": "<p>The accept data type, it must be 'application/json'.</p>"
          }
        ]
      }
    },
    "parameter": {
      "examples": [
        {
          "title": "Request-Body Example:",
          "content": "{\n  \"bookId\": \"1\",\n  \"amount\":\"1\",\n  \"price\":\"38.00\"，\n  \"userId\":\"1\"\n}",
          "type": "json"
        }
      ],
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "bookId",
            "description": "<p>the id of book.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "amount",
            "description": "<p>the number of book.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "price",
            "description": "<p>the price of book.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "userId",
            "description": "<p>the id of user.</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "  HTTP/1.1 200 OK\n{\n    \"result\":\"success\",\n    \"cartId\":\"1\"\n\n}",
          "type": "json"
        }
      ]
    },
    "filename": "src/main/java/com/xidian/bookstore/apidoc/CartApiDoc.java",
    "groupTitle": "CartMgmt"
  },
  {
    "type": "POST",
    "url": "/cart/delete",
    "title": "DeleteCart",
    "version": "1.0.0",
    "name": "DeleteCart",
    "group": "CartMgmt",
    "examples": [
      {
        "title": "Request-Example:",
        "content": "http://localhost/api/v1.0/cart/delete",
        "type": "Text"
      }
    ],
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "Content-Type",
            "description": "<p>The accept data type, it must be 'application/json'.</p>"
          }
        ]
      }
    },
    "parameter": {
      "examples": [
        {
          "title": "Request-Body Example:",
          "content": "{\n  \"cartId\":[\"1\",\"2\"]\n}",
          "type": "json"
        }
      ],
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Array",
            "optional": false,
            "field": "cartId",
            "description": "<p>the id of book.</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "  HTTP/1.1 200 OK\n{\n    \"result\":\"success\"\n}",
          "type": "json"
        }
      ]
    },
    "filename": "src/main/java/com/xidian/bookstore/apidoc/CartApiDoc.java",
    "groupTitle": "CartMgmt"
  },
  {
    "type": "GET",
    "url": "/cart/list",
    "title": "QueryCart",
    "version": "1.0.0",
    "name": "QueryCart",
    "group": "CartMgmt",
    "examples": [
      {
        "title": "Request-Example:",
        "content": "http://localhost/api/v1.0/cart/list?userId=1",
        "type": "Text"
      }
    ],
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "Content-Type",
            "description": "<p>The accept data type, it must be 'application/json'.</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "  HTTP/1.1 200 OK\n{\n    \"result\":\"success\"\n    \"data\":[\n     {\n         \"cartId\":\"1\",\n         \"bookId\":\"1\",\n         \"amount\":\"2\",\n         \"price\":\"38.00\",\n         \"createTime\":\"\"\n     },\n     {\n         \"cartId\":\"2\",\n         \"bookId\":\"2\",\n         \"amount\":\"1\",\n         \"price\":\"37.00\",\n         \"createTime\":\"\"\n     }\n    ]\n}",
          "type": "json"
        }
      ]
    },
    "filename": "src/main/java/com/xidian/bookstore/apidoc/CartApiDoc.java",
    "groupTitle": "CartMgmt"
  },
  {
    "type": "POST",
    "url": "/cart/update",
    "title": "UpdateCart",
    "version": "1.0.0",
    "name": "UpdateCart",
    "group": "CartMgmt",
    "examples": [
      {
        "title": "Request-Example:",
        "content": "http://localhost/api/v1.0/cart/update",
        "type": "Text"
      }
    ],
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "Content-Type",
            "description": "<p>The accept data type, it must be 'application/json'.</p>"
          }
        ]
      }
    },
    "parameter": {
      "examples": [
        {
          "title": "Request-Body Example:",
          "content": "{\n  \"amount\":\"1\",\n  \"price\":\"38.00\"，\n  \"cartId\":\"1\"\n}",
          "type": "json"
        }
      ],
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "amount",
            "description": "<p>the number of book.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "price",
            "description": "<p>the price of book.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "cartId",
            "description": "<p>the id of shoppingCart.</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "  HTTP/1.1 200 OK\n{\n    \"result\":\"success\"\n}",
          "type": "json"
        }
      ]
    },
    "filename": "src/main/java/com/xidian/bookstore/apidoc/CartApiDoc.java",
    "groupTitle": "CartMgmt"
  },
  {
    "type": "POST",
    "url": "/category/create",
    "title": "CreateCategory",
    "version": "1.0.0",
    "name": "CreateCategory",
    "group": "ClassMgmt",
    "examples": [
      {
        "title": "Request-Example:",
        "content": "http://localhost/api/v1.0/category/create",
        "type": "Text"
      }
    ],
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "Content-Type",
            "description": "<p>The accept data type, it must be 'application/json'</p>"
          }
        ]
      }
    },
    "parameter": {
      "examples": [
        {
          "title": "Request-Body Example:",
          "content": "{\n  \"name\": \"程序设计\",\n  \"description\": \"编程技术类书籍\"\n}",
          "type": "json"
        }
      ],
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>the name of category.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "description",
            "description": "<p>the description of category.</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "  HTTP/1.1 200 OK\n{\n    \"result\":\"success\"\n}",
          "type": "json"
        }
      ]
    },
    "filename": "src/main/java/com/xidian/bookstore/apidoc/ClassApiDoc.java",
    "groupTitle": "ClassMgmt"
  },
  {
    "type": "POST",
    "url": "/tag/create",
    "title": "CreateTag",
    "version": "1.0.0",
    "name": "CreateTag",
    "group": "ClassMgmt",
    "examples": [
      {
        "title": "Request-Example:",
        "content": "http://localhost/api/v1.0/tag/create",
        "type": "Text"
      }
    ],
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "Content-Type",
            "description": "<p>The accept data type, it must be 'application/json'</p>"
          }
        ]
      }
    },
    "parameter": {
      "examples": [
        {
          "title": "Request-Body Example:",
          "content": "{\n  \"name\": \"java\",\n  \"description\": \"java技术类书籍\"\n}",
          "type": "json"
        }
      ],
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>the name of tag.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "description",
            "description": "<p>the description of tag.</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "  HTTP/1.1 200 OK\n{\n    \"result\":\"success\"\n}",
          "type": "json"
        }
      ]
    },
    "filename": "src/main/java/com/xidian/bookstore/apidoc/ClassApiDoc.java",
    "groupTitle": "ClassMgmt"
  },
  {
    "type": "POST",
    "url": "/category/delete",
    "title": "DeleteCategory",
    "version": "1.0.0",
    "name": "DeleteCategory",
    "group": "ClassMgmt",
    "examples": [
      {
        "title": "Request-Example:",
        "content": "http://localhost/api/v1.0/category/delete",
        "type": "Text"
      }
    ],
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "Content-Type",
            "description": "<p>The accept data type, it must be 'application/json'</p>"
          }
        ]
      }
    },
    "parameter": {
      "examples": [
        {
          "title": "Request-Body Example:",
          "content": "{\n  \"categoryId\":[\"00\",\"10\",\"20\"]\n}",
          "type": "json"
        }
      ],
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Array",
            "optional": false,
            "field": "categoryId",
            "description": "<p>the id of category.</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "  HTTP/1.1 200 OK\n{\n    \"result\":\"success\"\n}",
          "type": "json"
        }
      ]
    },
    "filename": "src/main/java/com/xidian/bookstore/apidoc/ClassApiDoc.java",
    "groupTitle": "ClassMgmt"
  },
  {
    "type": "POST",
    "url": "/tag/delete",
    "title": "DeleteTag",
    "version": "1.0.0",
    "name": "DeleteTag",
    "group": "ClassMgmt",
    "examples": [
      {
        "title": "Request-Example:",
        "content": "http://localhost/api/v1.0/tag/delete",
        "type": "Text"
      }
    ],
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "Content-Type",
            "description": "<p>The accept data type, it must be 'application/json'</p>"
          }
        ]
      }
    },
    "parameter": {
      "examples": [
        {
          "title": "Request-Body Example:",
          "content": "{\n  \"tagId\":[\"01\",\"02\",\"03\"]\n}",
          "type": "json"
        }
      ],
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Array",
            "optional": false,
            "field": "tagId",
            "description": "<p>the id of tag.</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "  HTTP/1.1 200 OK\n{\n    \"result\":\"success\"\n}",
          "type": "json"
        }
      ]
    },
    "filename": "src/main/java/com/xidian/bookstore/apidoc/ClassApiDoc.java",
    "groupTitle": "ClassMgmt"
  },
  {
    "type": "GET",
    "url": "/category/list",
    "title": "QueryCategories",
    "version": "1.0.0",
    "name": "QueryCategories",
    "group": "ClassMgmt",
    "examples": [
      {
        "title": "Request-Example:",
        "content": "http://localhost/api/v1.0/category/list",
        "type": "Text"
      }
    ],
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "Content-Type",
            "description": "<p>The accept data type, it must be 'application/json'</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "  HTTP/1.1 200 OK\n{\n    \"result\":\"success\",\n    \"data\":{\n        \"00\":[\"01\",\"02\"],\n        \"10\":[\"11\",\"12\"],\n        \"20\":[\"21\",\"22\"]\n    }\n}",
          "type": "json"
        }
      ]
    },
    "filename": "src/main/java/com/xidian/bookstore/apidoc/ClassApiDoc.java",
    "groupTitle": "ClassMgmt"
  },
  {
    "type": "GET",
    "url": "/category/get",
    "title": "QueryCategory",
    "version": "1.0.0",
    "name": "QueryCategory",
    "group": "ClassMgmt",
    "examples": [
      {
        "title": "Request-Example:",
        "content": "http://localhost/api/v1.0/category/get?categoryId=1",
        "type": "Text"
      }
    ],
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "Content-Type",
            "description": "<p>The accept data type, it must be 'application/json'</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "  HTTP/1.1 200 OK\n{\n    \"name\":\"程序设计\",\n    \"description\":\"编程技术类书籍\"\n}",
          "type": "json"
        }
      ]
    },
    "filename": "src/main/java/com/xidian/bookstore/apidoc/ClassApiDoc.java",
    "groupTitle": "ClassMgmt"
  },
  {
    "type": "GET",
    "url": "/tag/get",
    "title": "QueryTag",
    "version": "1.0.0",
    "name": "QueryTag",
    "group": "ClassMgmt",
    "examples": [
      {
        "title": "Request-Example:",
        "content": "http://localhost/api/v1.0/tag/get?tagId=1",
        "type": "Text"
      }
    ],
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "Content-Type",
            "description": "<p>The accept data type, it must be 'application/json'</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "  HTTP/1.1 200 OK\n{\n    \"name\":\"java\",\n    \"description\":\"编程技术类书籍\"\n}",
          "type": "json"
        }
      ]
    },
    "filename": "src/main/java/com/xidian/bookstore/apidoc/ClassApiDoc.java",
    "groupTitle": "ClassMgmt"
  },
  {
    "type": "PUT",
    "url": "/category/update",
    "title": "UpdateCategory",
    "version": "1.0.0",
    "name": "UpdateCategory",
    "group": "ClassMgmt",
    "examples": [
      {
        "title": "Request-Example:",
        "content": "http://localhost/api/v1.0/category/update",
        "type": "Text"
      }
    ],
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "Content-Type",
            "description": "<p>The accept data type, it must be 'application/json'</p>"
          }
        ]
      }
    },
    "parameter": {
      "examples": [
        {
          "title": "Request-Body Example:",
          "content": "{\n  \"name\": \"程序设计\",\n  \"description\": \"编程技术类书籍\"\n}",
          "type": "json"
        }
      ],
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": true,
            "field": "name",
            "description": "<p>the name of category.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": true,
            "field": "description",
            "description": "<p>the description of category.</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "  HTTP/1.1 200 OK\n{\n    \"result\":\"success\"\n}",
          "type": "json"
        }
      ]
    },
    "filename": "src/main/java/com/xidian/bookstore/apidoc/ClassApiDoc.java",
    "groupTitle": "ClassMgmt"
  },
  {
    "type": "PUT",
    "url": "/tag/update",
    "title": "UpdateTag",
    "version": "1.0.0",
    "name": "UpdateTag",
    "group": "ClassMgmt",
    "examples": [
      {
        "title": "Request-Example:",
        "content": "http://localhost/api/v1.0/tag/update",
        "type": "Text"
      }
    ],
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "Content-Type",
            "description": "<p>The accept data type, it must be 'application/json'</p>"
          }
        ]
      }
    },
    "parameter": {
      "examples": [
        {
          "title": "Request-Body Example:",
          "content": "{\n  \"name\": \"java\",\n  \"description\": \"编程技术类书籍\"\n}",
          "type": "json"
        }
      ],
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": true,
            "field": "name",
            "description": "<p>the name of tag.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": true,
            "field": "description",
            "description": "<p>the description of tag.</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "  HTTP/1.1 200 OK\n{\n    \"result\":\"success\"\n}",
          "type": "json"
        }
      ]
    },
    "filename": "src/main/java/com/xidian/bookstore/apidoc/ClassApiDoc.java",
    "groupTitle": "ClassMgmt"
  },
  {
    "type": "POST",
    "url": "/logistics/create",
    "title": "CreateLogistics",
    "version": "1.0.0",
    "name": "CreateLogistics",
    "group": "LogisticsMgmt",
    "examples": [
      {
        "title": "Request-Example:",
        "content": "http://localhost/api/v1.0/logistics/create",
        "type": "Text"
      }
    ],
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "Content-Type",
            "description": "<p>The accept data type, it must be 'application/json'</p>"
          }
        ]
      }
    },
    "parameter": {
      "examples": [
        {
          "title": "Request-Body Example:",
          "content": "{\n  \"companyName\": \"顺丰\",\n  \"logisticsNumber\":\"269885214103\",\n  \"deliverTime\":\"\",\n  \"status\":\"\"\n}",
          "type": "json"
        }
      ],
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "companyName",
            "description": "<p>the name of logistics company.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "logisticsNumber",
            "description": "<p>the unique id of logistics.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "deliverTime",
            "description": "<p>the time of starting to deliver.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "status",
            "description": "<p>the description of logistics status.</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "  HTTP/1.1 200 OK\n{\n    \"result\":\"success\"\n}",
          "type": "json"
        }
      ]
    },
    "filename": "src/main/java/com/xidian/bookstore/apidoc/LogisticsApiDoc.java",
    "groupTitle": "LogisticsMgmt"
  },
  {
    "type": "DELETE",
    "url": "/logistics/delete",
    "title": "DeleteLogistics",
    "version": "1.0.0",
    "name": "DeleteLogistics",
    "group": "LogisticsMgmt",
    "examples": [
      {
        "title": "Request-Example:",
        "content": "http://localhost/api/v1.0/logistics/delete?logisticsId=1",
        "type": "Text"
      }
    ],
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "Content-Type",
            "description": "<p>The accept data type, it must be 'application/json'</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "  HTTP/1.1 200 OK\n{\n    \"result\":\"success\"\n}",
          "type": "json"
        }
      ]
    },
    "filename": "src/main/java/com/xidian/bookstore/apidoc/LogisticsApiDoc.java",
    "groupTitle": "LogisticsMgmt"
  },
  {
    "type": "POST",
    "url": "/logistics/search",
    "title": "QueryLogistics",
    "version": "1.0.0",
    "name": "QueryLogistics",
    "group": "LogisticsMgmt",
    "examples": [
      {
        "title": "Request-Example:",
        "content": "http://localhost/api/v1.0/logistics/search",
        "type": "Text"
      }
    ],
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "Content-Type",
            "description": "<p>The accept data type, it must be 'application/json'</p>"
          }
        ]
      }
    },
    "parameter": {
      "examples": [
        {
          "title": "Request-Body Example:",
          "content": "{\n   \"clause\":{\n       \"key1\": \"value1\",\n       \"keyn\":\"valuen\"\n     },\n   \"like\":{\n       \"key1\": \"value1\",\n       \"keyn\": \"valuen\"\n     },\n   \"filter\":\n   {\n       \"page\": \"0\",\n       \"size\": \"3\"\n\n   },\n   \"orderBy\":\n   {\n       \"field\": \"price\",\n       \"order\": \"asc\"\n   }\n\n}",
          "type": "json"
        }
      ],
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Object",
            "optional": true,
            "field": "clause",
            "description": "<p>Each item is &quot;And&quot; operation().</p>"
          },
          {
            "group": "Parameter",
            "type": "Object",
            "optional": true,
            "field": "like",
            "description": "<p>Each item is &quot;OR&quot; fuzzy search operation().</p>"
          },
          {
            "group": "Parameter",
            "type": "Object",
            "optional": false,
            "field": "filter",
            "description": "<p>Filter search result,we must select filter by paging.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "filter.page",
            "description": "<p>Filter search result by current page.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "filter.size",
            "description": "<p>Filter search result by size of the current page.</p>"
          },
          {
            "group": "Parameter",
            "type": "Object",
            "optional": true,
            "field": "orderBy",
            "description": "<p>Sort search result.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": true,
            "field": "orderBy.order",
            "description": "<p>Sort search result by DESCending or ASCending(&quot;asc&quot; or &quot;desc&quot;) default by asc.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": true,
            "field": "orderBy.field",
            "description": "<p>Sort search result by field . HTTP/1.1 200 OK { &quot;result&quot;:&quot;success&quot;, &quot;data&quot;:[ { &quot;logisticsId&quot;:&quot;1&quot;, &quot;companyName&quot;: &quot;顺丰&quot;, &quot;logisticsNumber&quot;:&quot;269885214103&quot;, &quot;deliverTime&quot;:&quot;&quot;, &quot;createTime&quot;:&quot;&quot;, &quot;status&quot;:&quot;&quot; }, { &quot;logisticsId&quot;:&quot;2&quot;, &quot;companyName&quot;: &quot;顺丰&quot;, &quot;logisticsNumber&quot;:&quot;269885215563&quot;, &quot;deliverTime&quot;:&quot;&quot;, &quot;createTime&quot;:&quot;&quot;, &quot;status&quot;:&quot;&quot; } ] }</p>"
          }
        ]
      }
    },
    "filename": "src/main/java/com/xidian/bookstore/apidoc/LogisticsApiDoc.java",
    "groupTitle": "LogisticsMgmt"
  },
  {
    "type": "PUT",
    "url": "/logistics/update",
    "title": "UpdateLogistics",
    "version": "1.0.0",
    "name": "UpdateLogistics",
    "group": "LogisticsMgmt",
    "examples": [
      {
        "title": "Request-Example:",
        "content": "http://localhost/api/v1.0/logistics/update",
        "type": "Text"
      }
    ],
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "Content-Type",
            "description": "<p>The accept data type, it must be 'application/json'</p>"
          }
        ]
      }
    },
    "parameter": {
      "examples": [
        {
          "title": "Request-Body Example:",
          "content": "{\n  \"companyName\": \"顺丰\",\n  \"logisticsNumber\":\"269885214103\",\n  \"deliverTime\":\"\",\n  \"status\":\"\"\n}",
          "type": "json"
        }
      ],
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": true,
            "field": "companyName",
            "description": "<p>the name of logistics company.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": true,
            "field": "logisticsNumber",
            "description": "<p>the unique id of logistics.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": true,
            "field": "deliverTime",
            "description": "<p>the time of starting to deliver.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": true,
            "field": "status",
            "description": "<p>the description of logistics status.</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "  HTTP/1.1 200 OK\n{\n    \"result\":\"success\"\n}",
          "type": "json"
        }
      ]
    },
    "filename": "src/main/java/com/xidian/bookstore/apidoc/LogisticsApiDoc.java",
    "groupTitle": "LogisticsMgmt"
  },
  {
    "type": "POST",
    "url": "/order/comment",
    "title": "CommentOrder",
    "version": "1.0.0",
    "name": "CommentOrder",
    "group": "OrderMgmt",
    "examples": [
      {
        "title": "Request-Example:",
        "content": "http://localhost/api/v1.0/order/comment",
        "type": "Text"
      }
    ],
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "Content-Type",
            "description": "<p>The accept data type, it must be 'application/json'</p>"
          }
        ]
      }
    },
    "parameter": {
      "examples": [
        {
          "title": "Request-Body Example:",
          "content": "{\n  \"bookId\": \"1\",\n  \"userId\":\"1\",\n  \"comment:\"good\"\n}",
          "type": "json"
        }
      ],
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "bookId",
            "description": "<p>the id of book.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "userId",
            "description": "<p>the id of user.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "comment",
            "description": "<p>the comment of book.</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "  HTTP/1.1 200 OK\n{\n    \"result\":\"success\"\n}",
          "type": "json"
        }
      ]
    },
    "filename": "src/main/java/com/xidian/bookstore/apidoc/OrderApiDoc.java",
    "groupTitle": "OrderMgmt"
  },
  {
    "type": "POST",
    "url": "/order/create",
    "title": "CreateOrder",
    "version": "1.0.0",
    "name": "CreateOrder",
    "group": "OrderMgmt",
    "examples": [
      {
        "title": "Request-Example:",
        "content": "http://localhost/api/v1.0/order/create",
        "type": "Text"
      }
    ],
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "Content-Type",
            "description": "<p>The accept data type, it must be 'application/json'</p>"
          }
        ]
      }
    },
    "parameter": {
      "examples": [
        {
          "title": "Request-Body Example:",
          "content": "{\n  \"bookId\": \"1\",\n  \"amount\":\"1\",\n  \"price\":\"38.00\"，\n  \"addressId\":\"1\",\n  \"userId\":\"1\",\n  \"description\":\"订单备注等\"\n}",
          "type": "json"
        }
      ],
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "bookId",
            "description": "<p>the id of book.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "amount",
            "description": "<p>the number of book.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "price",
            "description": "<p>the price of book.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "addressId",
            "description": "<p>the id of address.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "userId",
            "description": "<p>the id of user.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "description",
            "description": "<p>the description of order.</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "  HTTP/1.1 200 OK\n{\n    \"result\":\"success\"\n}",
          "type": "json"
        }
      ]
    },
    "filename": "src/main/java/com/xidian/bookstore/apidoc/OrderApiDoc.java",
    "groupTitle": "OrderMgmt"
  },
  {
    "type": "DELETE",
    "url": "/order/delete",
    "title": "DeleteOrder",
    "version": "1.0.0",
    "name": "DeleteOrder",
    "group": "OrderMgmt",
    "examples": [
      {
        "title": "Request-Example:",
        "content": "http://localhost/api/v1.0/order/delete?orderId=1",
        "type": "Text"
      }
    ],
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "Content-Type",
            "description": "<p>The accept data type, it must be 'application/json'.</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "  HTTP/1.1 200 OK\n{\n    \"result\":\"success\"\n}",
          "type": "json"
        }
      ]
    },
    "filename": "src/main/java/com/xidian/bookstore/apidoc/OrderApiDoc.java",
    "groupTitle": "OrderMgmt"
  },
  {
    "type": "GET",
    "url": "/order/get",
    "title": "QueryOrder",
    "version": "1.0.0",
    "name": "QueryOrder",
    "group": "OrderMgmt",
    "examples": [
      {
        "title": "Request-Example:",
        "content": "http://localhost/api/v1.0/order/get?status=0",
        "type": "Text"
      }
    ],
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "Content-Type",
            "description": "<p>The accept data type, it must be 'application/json'</p>"
          }
        ]
      }
    },
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "status",
            "description": "<p>the status of order(&quot;0&quot; means all orders,&quot;1&quot; means non-payment,&quot;2&quot; means to send the goods,&quot;&quot;3&quot; means to be confirmed,&quot;4&quot; means to be evaluated).</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "  HTTP/1.1 200 OK\n{\n    \"result\":\"success\"\n    \"data\":[\n     {\n         \"orderId\":\"1\",\n         \"bookId\": \"1\",\n         \"amount\":\"1\",\n         \"price\":\"38.00\"，\n         \"addressId\":\"1\",\n         \"status\":\"1\",\n         \"completeTime\":\"\",\n         \"createTime\":\"\",\n         \"logisticsId\":\"1\",\n         \"commentId\":\"2\",\n         \"paymentId\":\"1\",\n         \"addressId\":\"1\"\n     },\n     {\n         \"orderId\":\"1\",\n         \"bookId\": \"1\",\n         \"amount\":\"1\",\n         \"price\":\"38.00\"，\n         \"addressId\":\"1\",\n         \"status\":\"1\",\n         \"completeTime\":\"\",\n         \"createTime\":\"\",\n         \"logisticsId\":\"1\",\n         \"commentId\":\"2\",\n         \"paymentId\":\"1\",\n         \"addressId\":\"1\"\n     }\n    ]\n}",
          "type": "json"
        }
      ]
    },
    "filename": "src/main/java/com/xidian/bookstore/apidoc/OrderApiDoc.java",
    "groupTitle": "OrderMgmt"
  },
  {
    "type": "PUT",
    "url": "/order/update",
    "title": "UpdateOrder",
    "version": "1.0.0",
    "name": "UpdateOrder",
    "group": "OrderMgmt",
    "examples": [
      {
        "title": "Request-Example:",
        "content": "http://localhost/api/v1.0/order/update",
        "type": "Text"
      }
    ],
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "Content-Type",
            "description": "<p>The accept data type, it must be 'application/json'</p>"
          }
        ]
      }
    },
    "parameter": {
      "examples": [
        {
          "title": "Request-Body Example:",
          "content": "{\n  \"orderId\": \"1\",\n  \"logisticsId\":\"1\",\n  \"paymentId\":\"1\"\n}",
          "type": "json"
        }
      ],
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "orderId",
            "description": "<p>the id of order.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "logisticsId",
            "description": "<p>the id of logistics.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "paymentId",
            "description": "<p>the id of payment.</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "  HTTP/1.1 200 OK\n{\n    \"result\":\"success\"\n}",
          "type": "json"
        }
      ]
    },
    "filename": "src/main/java/com/xidian/bookstore/apidoc/OrderApiDoc.java",
    "groupTitle": "OrderMgmt"
  },
  {
    "type": "POST",
    "url": "/pay/create",
    "title": "CreatePayment",
    "version": "1.0.0",
    "name": "CreatePayment",
    "group": "PaymentMgmt",
    "examples": [
      {
        "title": "Request-Example:",
        "content": "http://localhost/api/v1.0/pay/create",
        "type": "Text"
      }
    ],
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "Content-Type",
            "description": "<p>The accept data type, it must be 'application/json'</p>"
          }
        ]
      }
    },
    "parameter": {
      "examples": [
        {
          "title": "Request-Body Example:",
          "content": "{\n  \"type\": \"微信\",\n  \"paymentNumber\":\"222359644420\"\n}",
          "type": "json"
        }
      ],
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "type",
            "description": "<p>the type of payment.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "paymentNumber",
            "description": "<p>the number of payment.</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "  HTTP/1.1 200 OK\n{\n    \"result\":\"success\"\n}",
          "type": "json"
        }
      ]
    },
    "filename": "src/main/java/com/xidian/bookstore/apidoc/PayApiDoc.java",
    "groupTitle": "PaymentMgmt"
  },
  {
    "type": "DELETE",
    "url": "/pay/delete",
    "title": "DeletePayment",
    "version": "1.0.0",
    "name": "DeletePayment",
    "group": "PaymentMgmt",
    "examples": [
      {
        "title": "Request-Example:",
        "content": "http://localhost/api/v1.0/pay/delete?paymentId=1",
        "type": "Text"
      }
    ],
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "Content-Type",
            "description": "<p>The accept data type, it must be 'application/json'</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "  HTTP/1.1 200 OK\n{\n    \"result\":\"success\"\n}",
          "type": "json"
        }
      ]
    },
    "filename": "src/main/java/com/xidian/bookstore/apidoc/PayApiDoc.java",
    "groupTitle": "PaymentMgmt"
  },
  {
    "type": "POST",
    "url": "/pay/search",
    "title": "QueryPayment",
    "version": "1.0.0",
    "name": "QueryPayment",
    "group": "PaymentMgmt",
    "examples": [
      {
        "title": "Request-Example:",
        "content": "http://localhost/api/v1.0/pay/search",
        "type": "Text"
      }
    ],
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "Content-Type",
            "description": "<p>The accept data type, it must be 'application/json'</p>"
          }
        ]
      }
    },
    "parameter": {
      "examples": [
        {
          "title": "Request-Body Example:",
          "content": "{\n   \"clause\":{\n       \"key1\": \"value1\",\n       \"keyn\":\"valuen\"\n     },\n   \"like\":{\n       \"key1\": \"value1\",\n       \"keyn\": \"valuen\"\n     },\n   \"filter\":\n   {\n       \"page\": \"0\",\n       \"size\": \"3\"\n\n   },\n   \"orderBy\":\n   {\n       \"field\": \"price\",\n       \"order\": \"asc\"\n   }\n\n}",
          "type": "json"
        }
      ],
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Object",
            "optional": true,
            "field": "clause",
            "description": "<p>Each item is &quot;And&quot; operation().</p>"
          },
          {
            "group": "Parameter",
            "type": "Object",
            "optional": true,
            "field": "like",
            "description": "<p>Each item is &quot;OR&quot; fuzzy search operation().</p>"
          },
          {
            "group": "Parameter",
            "type": "Object",
            "optional": false,
            "field": "filter",
            "description": "<p>Filter search result,we must select filter by paging.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "filter.page",
            "description": "<p>Filter search result by current page.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "filter.size",
            "description": "<p>Filter search result by size of the current page.</p>"
          },
          {
            "group": "Parameter",
            "type": "Object",
            "optional": true,
            "field": "orderBy",
            "description": "<p>Sort search result.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": true,
            "field": "orderBy.order",
            "description": "<p>Sort search result by DESCending or ASCending(&quot;asc&quot; or &quot;desc&quot;) default by asc.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": true,
            "field": "orderBy.field",
            "description": "<p>Sort search result by field .</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "  HTTP/1.1 200 OK\n{\n    \"result\":\"success\",\n    \"data\":[\n     {\n         \"type\":\"微信\",\n         \"paymentNumber\":\"222359644420\",\n         \"payTime\":\"\"\n     },\n     {\n         \"type\":\"微信\",\n         \"paymentNumber\":\"222359644420\",\n         \"payTime\":\"\"\n     }\n    ]\n}",
          "type": "json"
        }
      ]
    },
    "filename": "src/main/java/com/xidian/bookstore/apidoc/PayApiDoc.java",
    "groupTitle": "PaymentMgmt"
  },
  {
    "type": "POST",
    "url": "/picture/upload",
    "title": "UploadPicture",
    "version": "1.0.0",
    "name": "UploadPicture",
    "group": "PictureMgmt",
    "examples": [
      {
        "title": "Request-Example:",
        "content": "http://localhost/api/v1.0/picture/upload",
        "type": "Text"
      }
    ],
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "Content-Type",
            "description": "<p>The accept data type, it must be 'application/json'</p>"
          }
        ]
      }
    },
    "parameter": {
      "examples": [
        {
          "title": "Request-Body Example:",
          "content": "{\n\n}",
          "type": "Binary"
        }
      ]
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "  HTTP/1.1 200 OK\n{\n    \"result\":\"success\"\n}",
          "type": "json"
        }
      ]
    },
    "filename": "src/main/java/com/xidian/bookstore/apidoc/PictureApiDoc.java",
    "groupTitle": "PictureMgmt"
  },
  {
    "type": "POST",
    "url": "/user/login",
    "title": "Login",
    "version": "1.0.0",
    "name": "Login",
    "group": "UserMgmt",
    "examples": [
      {
        "title": "Request-Example:",
        "content": "http://localhost/api/v1.0/user/login",
        "type": "Text"
      }
    ],
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "Content-Type",
            "description": "<p>The accept data type, it must be 'application/json'</p>"
          }
        ]
      }
    },
    "parameter": {
      "examples": [
        {
          "title": "Request-Body Example:",
          "content": "{\n   \"email\": \"hcbbox@163.com\",\n   \"password\": \"123456\"\n}",
          "type": "json"
        }
      ],
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "email",
            "description": "<p>the email of user.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "password",
            "description": "<p>it will be used for logging.</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "  HTTP/1.1 200 OK\n{\n    \"respCode\":\"100\",\n    \"respMsg\":\"Successful\"\n    \"userId\":\"1\"\n}",
          "type": "json"
        }
      ]
    },
    "filename": "src/main/java/com/xidian/bookstore/apidoc/UserApiDoc.java",
    "groupTitle": "UserMgmt"
  },
  {
    "type": "PUT",
    "url": "/user/modify",
    "title": "ModifyPassword",
    "version": "1.0.0",
    "name": "ModifyPassword",
    "group": "UserMgmt",
    "examples": [
      {
        "title": "Request-Example:",
        "content": "http://localhost/api/v1.0/user/modify",
        "type": "Text"
      }
    ],
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "Content-Type",
            "description": "<p>The accept data type, it must be 'application/json'</p>"
          }
        ]
      }
    },
    "parameter": {
      "examples": [
        {
          "title": "Request-Body Example:",
          "content": "{\n   \"userId\":\"1\",\n   \"oldPassword\":\"123456\",\n   \"newPassword\":\"456789\"\n}",
          "type": "json"
        }
      ],
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "userId",
            "description": "<p>the id of user.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "oldPassword",
            "description": "<p>the old password.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "newPassword",
            "description": "<p>the new password.</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "  HTTP/1.1 200 OK\n{\n    \"respCode\":\"100\",\n    \"respMsg\":\"Successful\"\n}",
          "type": "json"
        }
      ]
    },
    "filename": "src/main/java/com/xidian/bookstore/apidoc/UserApiDoc.java",
    "groupTitle": "UserMgmt"
  },
  {
    "type": "GET",
    "url": "/user/get",
    "title": "QueryUser",
    "version": "1.0.0",
    "name": "QueryUser",
    "group": "UserMgmt",
    "examples": [
      {
        "title": "Request-Example:",
        "content": "http://localhost/api/v1.0/user/get?userId=1",
        "type": "Text"
      }
    ],
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "Content-Type",
            "description": "<p>The accept data type, it must be 'application/json'</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "  HTTP/1.1 200 OK\n{\n    \"respCode\":\"100\",\n    \"respMsg\":\"Successful\"\n    \"data\":{\n         \"userId\":\"2\",\n         \"uname\": \"小李\",\n         \"image\":\"\",\n         \"regTime\":\"\",\n         \"mobile\":\"13109535503\",\n         \"email\":\"abc@163.com\",\n         \"sex\":\"男\"\n   }\n}",
          "type": "json"
        }
      ]
    },
    "filename": "src/main/java/com/xidian/bookstore/apidoc/UserApiDoc.java",
    "groupTitle": "UserMgmt"
  },
  {
    "type": "GET",
    "url": "/user/list",
    "title": "QueryUsers",
    "version": "1.0.0",
    "name": "QueryUsers",
    "group": "UserMgmt",
    "examples": [
      {
        "title": "Request-Example:",
        "content": "http://localhost/api/v1.0/user/list",
        "type": "Text"
      }
    ],
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "Content-Type",
            "description": "<p>The accept data type, it must be 'application/json'</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "  HTTP/1.1 200 OK\n{\n    \"respCode\":\"100\",\n    \"respMsg\":\"Successful\"，\n    \"data\":[\n     {\n         \"userId\":\"1\",\n         \"uname\": \"小王\",\n         \"password\":\"123\",\n         \"image\":\"\",\n         \"regTime\":\"\",\n         \"mobile\":\"13109535503\",\n         \"email\":\"abc@163.com\",\n         \"sex\":\"男\"\n     },\n     {\n         \"userId\":\"2\",\n         \"uname\": \"小李\",\n         \"password\":\"123\",\n         \"image\":\"\",\n         \"regTime\":\"\",\n         \"mobile\":\"13109535503\",\n         \"email\":\"abc@163.com\",\n         \"sex\":\"男\"\n     }\n   ]\n}",
          "type": "json"
        }
      ]
    },
    "filename": "src/main/java/com/xidian/bookstore/apidoc/UserApiDoc.java",
    "groupTitle": "UserMgmt"
  },
  {
    "type": "POST",
    "url": "/user/register",
    "title": "Register",
    "version": "1.0.0",
    "name": "Register",
    "group": "UserMgmt",
    "examples": [
      {
        "title": "Request-Example:",
        "content": "http://localhost/api/v1.0/user/register",
        "type": "Text"
      }
    ],
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "Content-Type",
            "description": "<p>The accept data type, it must be 'application/json'</p>"
          }
        ]
      }
    },
    "parameter": {
      "examples": [
        {
          "title": "Request-Body Example:",
          "content": "{\n   \"email\":\"abc@163.com\"\n   \"password\": \"123456\",\n   \"code\":\"956142\"\n}",
          "type": "json"
        }
      ],
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "email",
            "description": "<p>the email of user.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "password",
            "description": "<p>it will be used for logging.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "code",
            "description": "<p>the verificationCode of user.</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "  HTTP/1.1 200 OK\n{\n    \"respCode\":\"100\",\n    \"respMsg\":\"Successful\"\n}",
          "type": "json"
        }
      ]
    },
    "filename": "src/main/java/com/xidian/bookstore/apidoc/UserApiDoc.java",
    "groupTitle": "UserMgmt"
  },
  {
    "type": "POST",
    "url": "/user/reset",
    "title": "ResetPassword",
    "version": "1.0.0",
    "name": "ResetPassword",
    "group": "UserMgmt",
    "examples": [
      {
        "title": "Request-Example:",
        "content": "http://localhost/api/v1.0/user/reset",
        "type": "Text"
      }
    ],
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "Content-Type",
            "description": "<p>The accept data type, it must be 'application/json'</p>"
          }
        ]
      }
    },
    "parameter": {
      "examples": [
        {
          "title": "Request-Body Example:",
          "content": "{\n   \"email\":\"abc@163.com\"\n   \"code\":\"123445\"\n}",
          "type": "json"
        }
      ],
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "email",
            "description": "<p>the email of user.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "code",
            "description": "<p>the verificationCode of user.</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "  HTTP/1.1 200 OK\n{\n    \"respCode\":\"100\",\n    \"respMsg\":\"Successful\"\n}",
          "type": "json"
        }
      ]
    },
    "filename": "src/main/java/com/xidian/bookstore/apidoc/UserApiDoc.java",
    "groupTitle": "UserMgmt"
  },
  {
    "type": "PUT",
    "url": "/user/update",
    "title": "UpdateInformation",
    "version": "1.0.0",
    "name": "UpdateInformation",
    "group": "UserMgmt",
    "examples": [
      {
        "title": "Request-Example:",
        "content": "http://localhost/api/v1.0/user/update",
        "type": "Text"
      }
    ],
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "Content-Type",
            "description": "<p>The accept data type, it must be 'application/json'</p>"
          }
        ]
      }
    },
    "parameter": {
      "examples": [
        {
          "title": "Request-Body Example:",
          "content": "{\n   \"userId\":\"1\",\n   \"uname\": \"小王\",\n   \"mobile\":\"13109535503\",\n   \"sex\":\"男\"\n}",
          "type": "json"
        }
      ],
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "userId",
            "description": "<p>the id of user.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": true,
            "field": "uname",
            "description": "<p>the name of user.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": true,
            "field": "mobile",
            "description": "<p>the phone number of user.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": true,
            "field": "sex",
            "description": "<p>the gender of user.</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "  HTTP/1.1 200 OK\n{\n    \"respCode\":\"100\",\n    \"respMsg\":\"Successful\"\n}",
          "type": "json"
        }
      ]
    },
    "filename": "src/main/java/com/xidian/bookstore/apidoc/UserApiDoc.java",
    "groupTitle": "UserMgmt"
  }
] });
